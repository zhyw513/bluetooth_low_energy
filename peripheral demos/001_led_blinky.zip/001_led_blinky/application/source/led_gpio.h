#ifndef _LED_GPIO_H_
#define _LED_GPIO_H_

#include "nrf_gpio.h"
#include "nordic_common.h"

#define LEDS_NUMBER   4 

#define LEDS_LIST    {NRF_GPIO_PIN_MAP(0,13), NRF_GPIO_PIN_MAP(0,14), NRF_GPIO_PIN_MAP(0,15), NRF_GPIO_PIN_MAP(0,16)}

#define LEDS_ACTIVE_STATE            0

extern void set_led_off(uint32_t led_index);
extern void set_led_on(uint32_t led_index);
extern void set_led_toggle(uint32_t led_index);
extern void set_all_leds_off(void);
extern void set_all_leds_on(void);
extern void set_all_leds_toggle(void);
extern void leds_gpio_init(void);

#endif
