#include <stdbool.h>
#include <stdint.h>
#include "nrf_delay.h"
#include "led_gpio.h"

/**
 * @brief Function for application main entry.
 */
int main(void)
{
    /* Configure board. */
    leds_gpio_init();

    /* Toggle LEDs. */
    while (true)
    {
        for(int i = 0; i < LEDS_NUMBER; i++)
        {
            set_all_leds_on();
            nrf_delay_ms(100);
            set_all_leds_off();
            nrf_delay_ms(100);
        }
    }
}

/**
 *@}
 **/

